package com.santander.mainclass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MainclassrunnerApplication {

    public static void main(String[] args) {
        SpringApplication.run(MainclassrunnerApplication.class, args);
    }

}
