package com.santander.backend.controller.controllermodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControllerApplicationTests {

    @Test
    void contextLoads() {
    }

}
